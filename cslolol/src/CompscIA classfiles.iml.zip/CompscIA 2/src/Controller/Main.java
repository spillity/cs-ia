package compscia.Controller;

public class Main {
    public static void main(String[] args) {
        App.launch();
    }
}